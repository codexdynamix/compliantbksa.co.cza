---
name: Managed artifact ports
description: Port conflicts that can occur when imported projects retain legacy workflows after artifact registration.
---

When an imported web artifact is registered with a managed service, any older manual workflow for the same app must be removed or it can keep the configured port occupied and prevent the managed preview from starting.

**Why:** Both workflows can launch the same Vite command with the same artifact port, producing a misleading startup failure even though the app itself is healthy.

**How to apply:** Prefer the registered managed artifact workflow. Remove the duplicate legacy workflow through the validated workspace configuration path, stop any stale process still holding the port, then restart the managed service.