---
name: Imported workspace dependencies
description: Setup behavior for imported pnpm workspaces when preview startup cannot find local binaries.
---

Freshly imported pnpm workspaces may have package manifests and a lockfile but no installed `node_modules`, causing managed preview workflows to fail with a missing executable such as `vite`.

**Why:** The imported project can look correctly configured while the workflow fails before the application starts.

**How to apply:** When an imported workspace reports `node_modules missing`, install from the existing lockfile before changing the workflow or application code.