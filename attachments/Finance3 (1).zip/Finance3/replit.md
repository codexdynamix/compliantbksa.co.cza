# Clarity Finance Advisory

A premium South African finance advisory website for founder-led businesses that want clearer numbers and calmer decisions.

## Run & Operate

- `pnpm --filter @workspace/clarity-finance-advisory run dev` — run the Vite website (Replit supplies `PORT` and `BASE_PATH`)
- `pnpm --filter @workspace/clarity-finance-advisory run typecheck` — typecheck the website
- `PORT=22127 BASE_PATH=/ pnpm --filter @workspace/clarity-finance-advisory run build` — create the production bundle locally
- No database or external service is required for the current website

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- React + Vite
- TypeScript
- Tailwind CSS v4
- Wouter for path-based page routing
- Lucide React for interface icons

## Where things live

- `artifacts/clarity-finance-advisory/src/App.tsx` — shared shell, routes, page compositions, FAQ, and consultation form
- `artifacts/clarity-finance-advisory/src/index.css` — visual system, responsive layout, motion, and reduced-motion rules
- `attached_assets/generated_images/` — the two restrained editorial images used by the site
- `artifacts/clarity-finance-advisory/.replit-artifact/artifact.toml` — artifact preview and service configuration

## Architecture decisions

- The site uses distinct client-side routes for `/`, `/approach`, `/services`, `/who-we-help`, `/faq`, and `/contact`, rather than presenting every section as one landing page.
- Navigation uses Wouter so direct path loads remain compatible with the artifact's path router and static fallback.
- Motion is intentionally restrained: page entrance, scroll reveal, small ambient hero movement, and hover feedback all respect `prefers-reduced-motion`.
- Imagery is limited to two local editorial assets so the brand feels considered rather than stock-photo heavy.

## Product

- Explains Clarity's accounting, tax, compliance, and advisory services
- Helps visitors assess whether the firm is a good fit
- Answers common questions through an accessible accordion
- Captures consultation enquiries through a client-side confirmation flow

## User preferences

- The user wants a sleek, compact, premium visual feel inspired by the restraint and polish of Apple products.
- The user prefers subtle, smooth animation and a small number of professional images.

## Gotchas

- Vite requires both `PORT` and `BASE_PATH`; use the artifact-provided environment when running through Replit.
- Keep new imagery local to `attached_assets/generated_images/` unless the user asks for a different asset workflow.

## Pointers
- The artifact service is declared in `artifacts/clarity-finance-advisory/.replit-artifact/artifact.toml`.
