import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { Link, Route, Switch, useLocation } from 'wouter';
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  Calculator,
  Check,
  ChevronDown,
  Clock3,
  FileSpreadsheet,
  Landmark,
  Mail,
  MapPin,
  Menu,
  Phone,
  ShieldCheck,
  TrendingUp,
  X,
} from 'lucide-react';
import { FaWhatsapp } from 'react-icons/fa6';
import brandLogo from '@assets/cbksa/logo.webp';
import heroImage from '@assets/cbksa/site/books.webp';
import meetingImage from '@assets/cbksa/site/meeting.webp';
import farmMastImage from '@assets/cbksa/site/farm-mast.webp';
import farmBannerImage from '@assets/cbksa/site/farm-banner.webp';
import planningImage from '@assets/cbksa/site/planning.webp';
import saicaLogo from '@assets/cbksa/logos/saica.svg';
import sageLogo from '@assets/cbksa/logos/sage.svg';
import xeroLogo from '@assets/cbksa/logos/xero.svg';
import saipaLogo from '@assets/cbksa/logos/saipa.webp';
import cibaLogo from '@assets/cbksa/logos/ciba-official.png';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';

const queryClient = new QueryClient();

const services = [
  { number: '01', icon: Calculator, title: 'Bookkeeping', text: 'Monthly bookkeeping and reconciliations that turn a pile of transactions into a picture your business can actually use.', tag: 'Reliable books' },
  { number: '02', icon: BarChart3, title: 'Management accounts', text: 'Meaningful monthly packs, reviewed and interpreted, so decisions are made with visibility rather than guesswork.', tag: 'Monthly packs' },
  { number: '03', icon: Landmark, title: 'VAT & tax support', text: 'VAT, PAYE and income tax handled on time, with a calm hand for queries so SARS is never a surprise.', tag: 'SARS support' },
  { number: '04', icon: FileSpreadsheet, title: 'Payroll', text: 'Sage Payroll run properly — payslips, EMP201s and the monthly rhythm taken off your desk.', tag: 'People paid' },
  { number: '05', icon: FileSpreadsheet, title: 'Financial statements', text: 'Annual financial statements prepared with care, ready for review, lenders, or the next conversation that matters.', tag: 'Year-end' },
  { number: '06', icon: TrendingUp, title: 'Cash-flow planning', text: 'Cash-flow forecasts that show what is coming, so you can move with intention rather than react under pressure.', tag: 'Forecasts' },
  { number: '07', icon: ShieldCheck, title: 'CIPC compliance', text: 'Annual returns, beneficial ownership and company secretarial housekeeping scheduled and done — off your mental load.', tag: 'Statutory work' },
  { number: '08', icon: BarChart3, title: 'Models & budgets', text: 'Financial models and budgets built for the actual business — not a template that pretends every client is the same.', tag: 'Decision support' },
  { number: '09', icon: Landmark, title: 'Loan & funding proposals', text: 'Clear packs for banks and funders: the numbers, the story, and the supporting schedules they actually ask for.', tag: 'Finance-ready' },
];

const faqs = [
  { question: 'Who do you work best with?', answer: 'Founder-led businesses, growing SMEs and established teams that want a finance function they can actually use. We also support professionals with personal and business tax needs.' },
  { question: 'Can you take over from our current accountant?', answer: 'Yes. We make the handover methodical: we review the current state, map open items, agree a clean starting point and give you a practical first-month plan.' },
  { question: 'Do you only work with businesses in South Africa?', answer: 'Our advisory is built around the South African operating context. We work primarily with local businesses and can coordinate with an existing team when an owner operates across borders.' },
  { question: 'What happens in the first consultation?', answer: 'It is a focused 30-minute conversation about where the numbers feel unclear, what is coming up next and what support would make the biggest difference. There is no obligation.' },
];

const navigation = [
  ['Home', '/'],
  ['Services', '/services'],
  ['Agriculture', '/agricultural-accounting'],
  ['Outsource', '/outsource'],
  ['Pricing', '/pricing'],
  ['Contact', '/contact'],
] as const;

function Wordmark({ footer = false }: { footer?: boolean }) {
  return (
    <span className={`wordmark ${footer ? 'wordmark-footer' : ''}`}>
      <img className="wordmark-logo" src={brandLogo} alt="" aria-hidden="true" />
      <span className="wordmark-type"><span>COMPLIANT</span><small>BOOKKEEPING SA</small></span>
    </span>
  );
}

function Eyebrow({ children, muted = false }: { children: ReactNode; muted?: boolean }) {
  return <span className={`eyebrow ${muted ? 'eyebrow-muted' : ''}`}><i aria-hidden="true" />{children}</span>;
}

function useReveals(location: string) {
  useEffect(() => {
    const items = Array.from(document.querySelectorAll<HTMLElement>('[data-reveal]'));
    if (!items.length) return;
    const show = (item: HTMLElement) => item.classList.add('is-visible');
    const revealItemsInView = () => {
      const threshold = window.innerHeight * 1.12;
      items.forEach((item) => {
        if (item.getBoundingClientRect().top <= threshold) show(item);
      });
    };

    if (!('IntersectionObserver' in window)) {
      items.forEach(show);
      return;
    }
    const observer = new IntersectionObserver((entries) => entries.forEach((entry) => {
      if (entry.isIntersecting) {
        show(entry.target as HTMLElement);
        observer.unobserve(entry.target);
      }
    }), { rootMargin: '0px 0px -8% 0px', threshold: 0.12 });
    items.forEach((item) => observer.observe(item));
    const frame = window.requestAnimationFrame(revealItemsInView);
    window.addEventListener('scroll', revealItemsInView, { passive: true });
    window.addEventListener('resize', revealItemsInView);
    return () => {
      window.cancelAnimationFrame(frame);
      window.removeEventListener('scroll', revealItemsInView);
      window.removeEventListener('resize', revealItemsInView);
      observer.disconnect();
    };
  }, [location]);
}

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [location] = useLocation();
  const darkHeader = location !== '/';
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 18);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  useEffect(() => setMenuOpen(false), [location]);
  const close = () => setMenuOpen(false);
  return (
    <header className={`site-header ${darkHeader ? 'site-header-dark' : ''} ${scrolled ? 'site-header-scrolled' : ''}`}>
      <nav className="header-inner" aria-label="Main navigation">
        <Link href="/" className="logo-link" data-testid="link-logo" aria-label="Compliant Bookkeeping SA home"><Wordmark /></Link>
        <div className="desktop-nav">
          {navigation.map(([label, href]) => <Link key={href} href={href} className="nav-link" data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`}>{label}</Link>)}
          <Link href="/contact" className="nav-cta" data-testid="link-nav-consultation">Book a consultation <ArrowUpRight aria-hidden="true" /></Link>
        </div>
        <button type="button" onClick={() => setMenuOpen(!menuOpen)} className="mobile-menu-button" aria-label={menuOpen ? 'Close navigation' : 'Open navigation'} aria-expanded={menuOpen} data-testid="button-mobile-menu">
          {menuOpen ? <X aria-hidden="true" /> : <Menu aria-hidden="true" />}
        </button>
      </nav>
      {menuOpen && <div className="mobile-nav">
        {[...navigation, ['Book a consultation', '/contact'] as const].map(([label, href]) => (
          <Link key={href} href={href} onClick={close} className="mobile-nav-link" data-testid={`link-mobile-${label.toLowerCase().replaceAll(' ', '-')}`}><span>{label}</span><ArrowUpRight aria-hidden="true" /></Link>
        ))}
      </div>}
    </header>
  );
}

function Footer() {
  return <footer className="site-footer">
    <div className="footer-inner">
      <Link href="/" className="logo-link" data-testid="link-footer-logo"><Wordmark footer /></Link>
      <div className="footer-links">
        <Link href="/services" data-testid="link-footer-services">Services</Link>
        <Link href="/agricultural-accounting" data-testid="link-footer-agriculture">Agriculture</Link>
        <Link href="/outsource" data-testid="link-footer-outsource">Outsource</Link>
        <Link href="/pricing" data-testid="link-footer-pricing">Pricing</Link>
        <Link href="/contact" data-testid="link-footer-contact">Contact</Link>
      </div>
      <div className="footer-meta"><span>Cape Town · Ceres · South Africa</span><span>© 2026 Compliant Bookkeeping SA</span></div>
    </div>
  </footer>;
}

function WhatsAppBubble() {
  return (
    <a
      href="https://wa.me/27834119467?text=Hello%20Compliant%20Bookkeeping%20SA%2C%20I%20would%20like%20to%20talk%20about%20bookkeeping%20support."
      target="_blank"
      rel="noreferrer"
      className="whatsapp-bubble"
      aria-label="Open WhatsApp for Compliant Bookkeeping SA"
      title="WhatsApp Compliant Bookkeeping SA"
      data-testid="button-whatsapp-support"
    >
      <FaWhatsapp aria-hidden="true" />
      <span>WhatsApp us</span>
    </a>
  );
}

function Layout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  useReveals(location);
  useEffect(() => { window.scrollTo({ top: 0, behavior: 'auto' }); }, [location]);
  return <div className="noise site-shell min-h-[100dvh]"><Header /><main key={location} className="page-transition">{children}</main><Footer /><WhatsAppBubble /></div>;
}

function Hero() {
  return <section className="hero-section">
    <div className="hero-gridline" aria-hidden="true" /><div className="hero-orbit hero-orbit-one" aria-hidden="true" /><div className="hero-orbit hero-orbit-two" aria-hidden="true" />
    <div className="hero-inner">
      <div className="hero-copy">
        <Eyebrow>Professional accounting</Eyebrow>
        <h1 className="hero-title animate-rise delay-1">Keeping your books <em>compliant.</em></h1>
        <p className="hero-intro animate-rise delay-2">Compliant Bookkeeping SA is your finance and compliance partner, providing accurate accounting and reliable financial support. We handle SARS, CIPC, VAT, PAYE, UIF/uFiling, COIDA and payroll, keeping your business compliant and your numbers in order.</p>
        <div className="hero-taglines animate-rise delay-2"><span>Keeping your books compliant.</span><span>Strengthening your numbers.</span><span>Supporting your growth.</span></div>
        <div className="hero-actions animate-rise delay-3"><a href="https://wa.me/27834119467?text=Hello%20Compliant%20Bookkeeping%20SA%2C%20I%20would%20like%20to%20talk%20about%20bookkeeping%20support." target="_blank" rel="noreferrer" className="button button-accent" data-testid="link-hero-whatsapp"><FaWhatsapp aria-hidden="true" /> WhatsApp</a><Link href="/contact" className="text-link text-link-light" data-testid="link-hero-contact">Request a conversation <ArrowRight aria-hidden="true" /></Link></div>
        <div className="hero-contact-badges animate-rise delay-3" aria-label="Contact options">
          <a className="hero-contact-badge hero-contact-whatsapp" href="https://wa.me/27834119467?text=Hello%20Compliant%20Bookkeeping%20SA%2C%20I%20would%20like%20to%20talk%20about%20bookkeeping%20support." target="_blank" rel="noreferrer">
            <span className="hero-contact-icon"><FaWhatsapp aria-hidden="true" /></span><span><small>WhatsApp</small><strong>083 411 9467</strong></span>
          </a>
          <a className="hero-contact-badge hero-contact-email" href="mailto:info@compliantbksa.co.za">
            <span className="hero-contact-icon"><Mail aria-hidden="true" /></span><span><small>Email</small><strong>info@compliantbksa.co.za</strong></span>
          </a>
          <a className="hero-contact-badge hero-contact-maps" href="https://www.google.com/maps/search/?api=1&query=23+Bridge+Street%2C+Rosebank%2C+Cape+Town%2C+7700" target="_blank" rel="noreferrer">
            <span className="hero-contact-icon"><MapPin aria-hidden="true" /></span><span><small>Maps</small><strong>Cape Town · Ceres</strong></span>
          </a>
        </div>
      </div>
      <figure className="hero-source-visual animate-rise delay-2"><img src={heroImage} alt="Printed annual financial statements, a fountain pen and a laptop on a desk" /><figcaption><strong>The numbers, in order</strong><span>Bookkeeping · Reporting · Financial statements</span></figcaption></figure>
    </div>
    <div className="hero-footerline"><span className="hero-scroll"><i /> Scroll to explore</span><span className="hero-location">Cape Town · South Africa</span></div>
  </section>;
}

function PracticeProof() {
  return <section className="practice-proof" aria-label="Practice highlights">
    <div className="section-inner">
      <div className="practice-proof-heading"><Eyebrow>Built for the real work</Eyebrow><h2>Professional standards. Clear <em>support.</em></h2><p>Two Western Cape offices, one standard of work. Reach the practice by the channel that suits you.</p></div>
      <div className="practice-proof-grid">
        <div className="practice-proof-card"><Phone aria-hidden="true" /><Eyebrow>Reachable</Eyebrow><h3>Phone, WhatsApp or email</h3><p>A practice you can actually reach — by the channel that suits you.</p></div>
        <div className="practice-proof-card"><ShieldCheck aria-hidden="true" /><Eyebrow>Affiliated</Eyebrow><h3>Professional bodies</h3><p>SAICA, SAIPA and CIBA — professional bodies your clients already recognise.</p></div>
        <div className="practice-proof-card"><FileSpreadsheet aria-hidden="true" /><Eyebrow>Software</Eyebrow><h3>Familiar ledgers</h3><p>Sage, Sage Payroll and Xero — we work in the ledgers you already run.</p></div>
        <div className="practice-proof-card"><MapPin aria-hidden="true" /><Eyebrow>Places</Eyebrow><h3>Cape Town &amp; Ceres</h3><p>Two Western Cape offices, one standard of work.</p></div>
      </div>
    </div>
  </section>;
}

function AffiliationsSection() {
  return <section className="affiliations-section" aria-labelledby="affiliations-title">
    <div className="section-inner">
      <div className="section-heading affiliations-heading"><div><Eyebrow>Affiliated to</Eyebrow><h2 id="affiliations-title">Professional bodies your clients already <em>recognise.</em></h2></div><p>The supplied affiliation badges are shown as provided, without recolouring or recreating them.</p></div>
      <div className="affiliation-badge-grid">
        <div className="affiliation-badge"><img src={saicaLogo} alt="South African Institute of Chartered Accountants" /><strong>South African Institute of Chartered Accountants</strong></div>
        <div className="affiliation-badge"><img className="affiliation-badge-saipa" src={saipaLogo} alt="South African Institute of Professional Accountants" /><strong>South African Institute of Professional Accountants</strong></div>
        <div className="affiliation-badge"><img className="affiliation-badge-ciba" src={cibaLogo} alt="CIBA — Chartered Institute for Business Accountants NPC" /><strong>Professional body your clients already recognise</strong></div>
      </div>
    </div>
  </section>;
}

function SoftwareSection() {
  return <section className="software-section" aria-labelledby="software-title">
    <div className="section-inner software-inner">
      <div className="software-copy"><Eyebrow>Software</Eyebrow><h2 id="software-title">We use the following <em>software.</em></h2><p>Cloud accounting, payroll and bank feeds in the systems your business or practice already runs.</p></div>
      <div className="software-grid">
        <div className="software-card"><img src={sageLogo} alt="Sage Accounting" /><strong>Sage Accounting</strong><span>Accounting and bank feeds</span></div>
        <div className="software-card"><img src={sageLogo} alt="Sage Payroll" /><strong>Sage Payroll</strong><span>Payslips and payroll returns</span></div>
        <div className="software-card"><img src={xeroLogo} alt="Xero" /><strong>Xero</strong><span>Cloud reporting and reconciliations</span></div>
      </div>
    </div>
  </section>;
}

function HomePricingBand() {
  return <section className="home-pricing-band" aria-labelledby="home-pricing-title">
    <div className="section-inner home-pricing-inner">
      <div><Eyebrow>Pricing</Eyebrow><h2 id="home-pricing-title">R1,000 a <em>month.</em></h2><p>Example monthly starting points. Final fees depend on entity size, transaction volume, payroll and the services you need.</p></div>
      <Link href="/pricing" className="button button-dark">See example pricing <ArrowRight aria-hidden="true" /></Link>
    </div>
  </section>;
}

function ApproachSection() {
  return <section id="approach" className="approach-section">
    <div className="section-inner approach-inner">
      <div className="section-marker"><Eyebrow>Our approach</Eyebrow><span className="marker-number">01</span></div>
      <div className="approach-content" data-reveal><h2>Your numbers should answer questions, not create more of them.</h2><div className="approach-notes"><p>We bring structure to the everyday and perspective to the important moments. No jargon wall. No mysterious month-end.</p><p>Just accurate financial foundations, a clear view of what is changing, and a partner who knows when to zoom in.</p></div><div className="approach-signoff"><div className="initials" aria-hidden="true">{['C', 'M', 'N'].map((initial, index) => <span key={initial} className={index === 1 ? 'initial-accent' : ''}>{initial}</span>)}</div><span>A steady hand for the decisions ahead.</span></div></div>
    </div>
  </section>;
}

function EditorialSection() {
  return <section className="visual-break-section" aria-label="A closer look at the Compliant Bookkeeping SA approach">
    <div className="section-inner visual-break-inner"><div className="visual-break-copy" data-reveal><Eyebrow>Start with a conversation</Eyebrow><h2>Clear books. Thoughtful <em>reporting.</em></h2><p>At Compliant Bookkeeping SA, the work starts with a conversation. We bring professional accounting, payroll and compliance to clients who want the numbers handled — and explained — without the noise.</p><div className="visual-break-caption"><span className="caption-dot" aria-hidden="true" />No mystery month-end</div></div>
      <div className="visual-break-gallery"><figure className="visual-break-photo visual-break-photo-wide" data-reveal><img src={meetingImage} alt="Advisors reviewing management accounts together" /><figcaption>01 / A better conversation about the numbers</figcaption></figure><figure className="visual-break-photo visual-break-photo-detail" data-reveal><img src={planningImage} alt="Advisor reviewing a funding proposal with a client" /><figcaption>02 / Details, handled</figcaption></figure></div>
    </div>
  </section>;
}

function ServicesList({ compact = false }: { compact?: boolean }) {
  return <div className={`service-list ${compact ? 'service-list-compact' : ''}`}>{services.map(({ number, icon: Icon, title, text, tag }) => <article key={number} className="service-row" data-reveal data-testid={`card-service-${number}`}><span className="service-number">{number}</span><div className="service-icon"><Icon aria-hidden="true" /></div><div className="service-main"><h3>{title}</h3><p>{text}</p></div><span className="service-tag">{tag}</span><ArrowUpRight className="service-arrow" aria-hidden="true" /></article>)}</div>;
}

function ServicesSection() {
  return <section id="services" className="services-section"><div className="section-inner"><div className="section-heading services-heading"><div><Eyebrow>The useful stuff</Eyebrow><h2>Finance that <em>moves</em> with you.</h2></div><p>The right support changes as your business changes. Start where the friction is.</p></div><ServicesList /></div></section>;
}

function FitSection() {
  const fitItems = ['A founder making the first serious hires', 'An SME ready for cleaner management information', 'An established business navigating a new chapter', 'A professional with more moving parts than time'];
  return <section id="fit" className="fit-section"><div className="section-inner fit-inner"><div className="fit-copy" data-reveal><Eyebrow>A good fit looks like</Eyebrow><h2>You want a finance partner, not a <em>filing cabinet.</em></h2><p>You care about doing things properly, but you have a business to run. You want answers that arrive before the deadline — and advice that respects the real-world trade-offs.</p></div><div className="fit-list" data-reveal>{fitItems.map((item, index) => <div key={item} className="fit-item"><span>{`0${index + 1}`}</span><strong>{item}</strong></div>)}<Link href="/contact" className="text-link text-link-dark fit-link" data-testid="link-fit-contact">Let&apos;s see if we fit <ArrowRight aria-hidden="true" /></Link></div></div></section>;
}

function StandardSection() {
  return <section className="standard-section"><div className="section-inner standard-inner"><div className="standard-heading"><Eyebrow>The Compliant standard</Eyebrow><h2>The work is practical. The difference is how it feels.</h2></div><div className="standard-list">{[['01', 'Keep you compliant', 'SARS, CIPC and payroll dates are our calendar — so they never become yours.'], ['02', 'Strengthen the numbers', 'Books that answer questions, not another month-end you have to decode.'], ['03', 'Support your growth', 'We start with what is actually happening in the business, not a template.']].map(([number, title, text]) => <div key={number} className="standard-item" data-reveal><Eyebrow>{number}</Eyebrow><h3>{title}</h3><p>{text}</p></div>)}</div></div></section>;
}

function FaqList() {
  const [openFaq, setOpenFaq] = useState(0);
  return <div className="faq-list" data-reveal>{faqs.map(({ question, answer }, index) => { const isOpen = openFaq === index; return <div key={question} className="faq-item"><button type="button" onClick={() => setOpenFaq(isOpen ? -1 : index)} className="faq-trigger" aria-expanded={isOpen} data-testid={`button-faq-${index}`}><span>{question}</span><ChevronDown className={isOpen ? 'faq-chevron faq-chevron-open' : 'faq-chevron'} aria-hidden="true" /></button><div className={`faq-content ${isOpen ? 'open' : ''}`}><div className="faq-answer"><p data-testid={`text-faq-answer-${index}`}>{answer}</p></div></div></div>; })}</div>;
}

function FaqSection() {
  return <section id="faq" className="faq-section"><div className="section-inner faq-inner-layout"><div><Eyebrow>Good to know</Eyebrow><h2>Before we <em>talk.</em></h2></div><FaqList /></div></section>;
}

function ContactForm() {
  const [submitted, setSubmitted] = useState(false);
  const submitForm = (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); setSubmitted(true); };
  if (submitted) return <div className="form-success" data-testid="status-form-success"><Check aria-hidden="true" /><Eyebrow>Message received</Eyebrow><h3>That&apos;s a good first step.</h3><p>Thank you for reaching out. We&apos;ll review your note and come back with a useful next step.</p><button type="button" onClick={() => setSubmitted(false)} className="reset-button" data-testid="button-form-reset">Send another note</button></div>;
  return <form onSubmit={submitForm} className="consultation-form" data-testid="form-consultation"><div className="form-heading"><Eyebrow>Send a note</Eyebrow><h3>Tell us what&apos;s on the books.</h3></div><div className="form-fields-two"><label><span className="field-label">Your name</span><input required name="name" type="text" placeholder="First and last name" data-testid="input-name" /></label><label><span className="field-label">Phone number</span><input required name="phone" type="tel" inputMode="tel" placeholder="083 411 9467" data-testid="input-phone" /></label></div><label><span className="field-label">Email address</span><input required name="email" type="email" placeholder="info@compliantbksa.co.za" data-testid="input-email" /></label><label><span className="field-label">What would you like help with?</span><select required name="focus" defaultValue="" data-testid="select-focus"><option value="" disabled>Select a focus</option><option value="bookkeeping">Bookkeeping and reporting</option><option value="tax">VAT and tax</option><option value="payroll">Payroll</option><option value="agricultural">Agricultural accounting</option><option value="outsource">Outsourcing for my firm</option><option value="pricing">Pricing for my business</option><option value="other">Something else</option></select></label><label><span className="field-label">A little context <small>(optional)</small></span><textarea name="message" rows={3} placeholder="Share the software you use, the deadlines that worry you, and what “done” looks like." data-testid="textarea-context" /></label><button type="submit" className="button button-dark form-submit" data-testid="button-submit-consultation">Send enquiry <ArrowRight aria-hidden="true" /></button><p className="privacy-note">Your note can also be sent directly to <a href="mailto:info@compliantbksa.co.za">info@compliantbksa.co.za</a>.</p></form>;
}

function ContactSection() {
  return <section id="contact" className="contact-section"><div className="section-inner contact-inner"><div className="contact-copy"><Eyebrow muted>Make the numbers useful</Eyebrow><h2>A clearer next step starts <em>here.</em></h2><p>Write, call, or WhatsApp Compliant Bookkeeping SA. Tell us what is on the books and we will come back with a practical next step — never a hard sell.</p><div className="contact-details"><div><Clock3 aria-hidden="true" /> Two offices in the Western Cape</div><div><ShieldCheck aria-hidden="true" /> No obligation, no hard sell</div></div><div className="contact-directory" aria-label="Contact details"><div className="contact-directory-item"><Mail aria-hidden="true" /><span><small>Email</small><strong><a href="mailto:info@compliantbksa.co.za">info@compliantbksa.co.za</a></strong></span></div><div className="contact-directory-item"><Mail aria-hidden="true" /><span><small>Accounts</small><strong><a href="mailto:accounting@compliantbksa.co.za">accounting@compliantbksa.co.za</a></strong></span></div><div className="contact-directory-item"><Phone aria-hidden="true" /><span><small>Primary · Alternate</small><strong><a href="tel:+27834119467">083 411 9467</a> · <a href="tel:+27742063255">074 206 3255</a></strong></span></div><div className="contact-directory-item"><MapPin aria-hidden="true" /><span><small>Offices</small><strong>Cape Town · Ceres</strong></span></div></div></div><div className="form-panel" data-reveal><ContactForm /></div></div></section>;
}

function HomePage() {
  return <><Hero /><PracticeProof /><AffiliationsSection /><SoftwareSection /><HomePricingBand /><ApproachSection /><EditorialSection /><ServicesSection /><FitSection /><StandardSection /><FaqSection /><ContactSection /></>;
}

function InteriorHero({ kicker, title, intro, index }: { kicker: string; title: ReactNode; intro: string; index: string }) {
  return <section className="interior-hero"><div className="section-inner interior-hero-inner"><div className="interior-index">{index}</div><div><Eyebrow>{kicker}</Eyebrow><h1>{title}</h1><p>{intro}</p></div></div></section>;
}

function ApproachPage() {
  return <><InteriorHero kicker="The way we work" title={<>Clear books. Thoughtful <em>reporting.</em></>} intro="At Compliant Bookkeeping SA, the work starts with a conversation. We bring professional accounting, payroll and compliance to clients who want the numbers handled — and explained — without the noise." index="01" /><ApproachSection /><EditorialSection /><StandardSection /><ContactSection /></>;
}

function ServicesPage() {
  return <><InteriorHero kicker="What we do" title={<>The right detail. The wider <em>view.</em></>} intro="From the first transaction to a finished set of statements, we bring specialist focus to accuracy, deadlines and a pack you can take into the next conversation." index="02" /><section className="services-section services-page-section"><div className="section-inner"><div className="section-heading services-heading"><div><Eyebrow>Nine disciplines</Eyebrow><h2>Less admin. More <em>agency.</em></h2></div><p>Choose the support your business needs now. We can grow the relationship as the picture changes.</p></div><ServicesList /></div></section><FitSection /><ContactSection /></>;
}

function WhoWeHelpPage() {
  return <><InteriorHero kicker="Who we help" title={<>Ambition, with the <em>foundations</em> to match.</>} intro="Compliant Bookkeeping SA is for people building something real — with enough momentum to need better answers, and enough care to want them done properly." index="03" /><FitSection /><section className="profile-section"><div className="section-inner profile-grid"><div><Eyebrow>Different stages. Same standard.</Eyebrow><h2>Wherever you are, the question is usually the same.</h2></div><div className="profile-notes"><div data-reveal><span>01</span><h3>“Can we see what is really happening?”</h3><p>For founders hiring, investing or preparing to scale.</p></div><div data-reveal><span>02</span><h3>“How do we make the next call well?”</h3><p>For established teams navigating a new chapter.</p></div></div></div></section><ContactSection /></>;
}

function FaqPage() {
  return <><InteriorHero kicker="Good to know" title={<>The useful answers, <em>up front.</em></>} intro="A first conversation should feel straightforward. Here are the questions we hear most often." index="04" /><FaqSection /><section className="faq-callout"><div className="section-inner callout-inner"><Eyebrow>Still wondering?</Eyebrow><h2>Bring the question. We&apos;ll bring the <em>context.</em></h2><Link href="/contact" className="button button-accent" data-testid="link-faq-contact">Start a conversation <ArrowRight aria-hidden="true" /></Link></div></section></>;
}

function ContactPage() {
  return <><InteriorHero kicker="Contact us" title={<>Two addresses. Direct lines. A practice you can <em>reach.</em></>} intro="Write, call, or WhatsApp Compliant Bookkeeping SA — we love meeting new clients and practices." index="05" /><ContactSection /><section className="contact-note"><div className="section-inner contact-note-inner"><div><Eyebrow>What happens next</Eyebrow><h2>Tell us what is on the <em>books.</em></h2></div><div className="next-steps"><div data-reveal><span>CAPE TOWN</span><p>23 Bridge Street, Rosebank, Cape Town, Western Cape, 7700</p><a href="https://www.google.com/maps/search/?api=1&query=23+Bridge+Street%2C+Rosebank%2C+Cape+Town%2C+7700" target="_blank" rel="noreferrer">Open in Maps</a></div><div data-reveal><span>CERES</span><p>8 Rietvalley Street, Ceres, Western Cape, 6835</p><a href="https://www.google.com/maps/search/?api=1&query=8+Rietvalley+Street%2C+Ceres%2C+Western+Cape%2C+6835" target="_blank" rel="noreferrer">Open in Maps</a></div></div></div></section></>;
}

const agriculturalServices = [
  ['Farm bookkeeping', 'Seasonal books that keep pace with harvests, input cycles and livestock movements.'],
  ['Management accounts', 'Monthly packs that show what the land, the herd and the season actually produced.'],
  ['Cash-flow planning', 'Forecasts built around planting, payouts and the long wait between them.'],
  ['Financial statements', 'Year-end statements prepared with farming realities in mind.'],
  ['VAT & tax support', 'VAT, diesel refunds and farming tax treated as the specialist work they are.'],
  ['Payroll', 'Seasonal and permanent payroll, UIF and the returns that go with it.'],
  ['Loan & funding proposals', 'Bank-ready packs for production loans, equipment finance and Land Bank conversations.'],
  ['CIPC compliance', 'Company, CC and trust housekeeping kept current so funding is not delayed by admin.'],
  ['Financial models & budgets', 'Crop, herd and input models you can take into a lender meeting.'],
  ['Record keeping', 'Source documents, asset registers and production records organised for the next audit or grant.'],
];

function AgriculturalPage() {
  return <><InteriorHero kicker="Specialist desk" title={<>Agricultural <em>accounting.</em></>} intro="Helping farmers stay compliant, financially organised and finance-ready. Farming has its own calendar, its own cash cycle, and its own SARS questions." index="06" /><section className="source-feature-section"><div className="section-inner source-feature-grid"><div className="source-feature-copy" data-reveal><Eyebrow>Services include</Eyebrow><h2>Built around the farming <em>year.</em></h2><p>This is the specialist desk for agricultural accounting — from record keeping to funding proposals.</p><img src={farmMastImage} alt="Western Cape farmland" /></div><ol className="source-ledger-list">{agriculturalServices.map(([title, text], index) => <li key={title} data-reveal><span>{String(index + 1).padStart(2, '0')}</span><div><h3>{title}</h3><p>{text}</p></div></li>)}</ol></div></section><section className="source-season-section"><div className="section-inner source-season-inner" data-reveal><Eyebrow>Why it is different</Eyebrow><h2>The season is the real financial <em>year.</em></h2><ul><li>Books that follow planting, livestock and payout cycles</li><li>VAT, diesel and farming tax treated as specialist work</li><li>Lender-ready statements, models and cash-flow notes</li></ul><img src={farmBannerImage} alt="Western Cape farmland at dusk" /></div></section><section className="band-light"><div className="section-inner band-copy"><Eyebrow>Farm packages</Eyebrow><h2>Farm accounting packages from R1,500 per month</h2><p>Pricing is based on farm size, transaction volume, payroll and services required.</p><Link href="/contact" className="text-link text-link-dark">Agricultural enquiry <ArrowRight aria-hidden="true" /></Link></div></section><ContactSection /></>;
}

const outsourceServices = [
  ['Bookkeeping & accounting', 'Capture, recs and packs prepared to your review standard.'],
  ['Payroll', 'Sage Payroll processed so your managers are not spending month-end on EMP201s.'],
  ['Taxation', 'VAT201s, income tax workings and SARS follow-up, ready for the practitioner’s sign-off.'],
  ['Cloud automation', 'Sage Accounting and Xero kept clean, with bank feeds and schedules that survive review.'],
  ['Company secretarial', 'CIPC annual returns and beneficial ownership processed in batches for a firm’s client base.'],
  ['Consulting support', 'Cash-flow, budgets and funding workings when a client file needs more than the close.'],
];

function OutsourcePage() {
  const steps = [['Call us', 'Book a conversation. We learn the software, the review standard, and where the bottleneck is.'], ['We plan', 'A package that suits the size of the file, the industry, and how you like work delivered.'], ['You sleep easy', 'We get to work. You review. Your clients stay yours.']];
  return <><InteriorHero kicker="For practices" title={<>Outsource to us. <em>Keep the client.</em></>} intro="Hassle-free accounting, tax & bookkeeping — on your terms. We handle the numbers so your business or practice can take flight." index="07" /><section className="outsource-belief"><div className="section-inner"><Eyebrow>Need extra capacity without hiring more staff?</Eyebrow><h2>Focus on serving your clients. <em>We will handle the numbers.</em></h2><p>You did not build a practice to live in working papers. Time spent catching up books, payroll and VAT is time you are not spending on the relationships that grow the firm. Outsource the production. Keep the client.</p></div></section><section className="source-scope-section"><div className="section-inner"><div className="source-scope-heading"><Eyebrow>What we take on</Eyebrow><h2>A full-service team, behind your <em>name.</em></h2></div><div className="source-scope-list">{outsourceServices.map(([title, text]) => <div key={title} data-reveal><h3>{title}</h3><p>{text}</p></div>)}</div></div></section><section className="source-plan-section"><div className="section-inner"><Eyebrow>The 3-step plan</Eyebrow><h2>The building blocks for extra <em>capacity.</em></h2><div className="source-plan-grid">{steps.map(([title, text], index) => <div key={title} data-reveal><span>0{index + 1}</span><h3>{title}</h3><p>{text}</p></div>)}</div><ul className="source-benefits"><li>Overflow in peak VAT and year-end without a permanent hire</li><li>Workpapers prepared to your review notes</li><li>Sage Accounting, Sage Payroll and Xero — no software migration required</li></ul></div></section><ContactSection /></>;
}

const priceTiers = [
  ['Small / micro entity', 'From R1,000 pm', 'Straightforward books, a modest transaction volume, and the monthly compliance rhythm.'],
  ['Growing business', 'From R1,500–R2,500 pm', 'More activity, payroll, VAT and reporting that needs a closer monthly review.'],
  ['Medium entity', 'From R3,000 pm', 'Multiple ledgers, staff, VAT and a pack that supports management decisions.'],
  ['Larger / complex entity', 'Tailored quote', 'Group structures, higher volume or specialised reporting — scoped around the actual work.'],
];

function PricingPage() {
  return <><InteriorHero kicker="Pricing" title={<>Clear packages. <em>Scoped to the books.</em></>} intro="Monthly accounting starts from R1,000. The right package depends on the size of the entity, transaction volume, payroll and the services you need — we confirm that before any work begins." index="08" /><section className="pricing-tiers"><div className="section-inner pricing-grid">{priceTiers.map(([size, price, detail], index) => <article key={size} className={index === 1 ? 'pricing-card pricing-card-featured' : 'pricing-card'} data-reveal>{index === 1 && <span className="pricing-flag">Typical starting range</span>}<Eyebrow>{size}</Eyebrow><strong>{price}</strong><p>{detail}</p><Link href="/contact" className={index === 3 ? 'button button-dark' : 'text-link text-link-dark'}>{index === 3 ? 'Request a quote' : 'Talk about this package'} <ArrowRight aria-hidden="true" /></Link></article>)}</div><p className="section-inner pricing-note">Figures are example monthly starting points, excluding VAT where applicable. Final fees are confirmed after we see the software, the volume and the deadlines.</p></section><section className="pricing-includes"><div className="section-inner pricing-includes-inner"><div><Eyebrow>What a package typically covers</Eyebrow><h2>The work that keeps you <em>compliant.</em></h2><p>Every engagement is scoped. The list below is the core of most monthly retainers — we add or leave out according to the entity.</p></div><ul>{['Monthly bookkeeping and bank reconciliations', 'SARS, VAT, PAYE and related returns as scoped', 'CIPC housekeeping kept on the calendar', 'Payroll, UIF/uFiling and COIDA where required', 'A pack you can actually use — not just a file dump'].map(item => <li key={item}><Check aria-hidden="true" />{item}</li>)}</ul></div></section><section className="band-dark"><div className="section-inner band-copy"><Eyebrow>Farm packages</Eyebrow><h2>Farm accounting packages from R1,500 per month</h2><p>Pricing is based on farm size, transaction volume, payroll and services required.</p><Link href="/agricultural-accounting" className="text-link text-link-light">See agricultural accounting <ArrowRight aria-hidden="true" /></Link></div></section><ContactSection /></>;
}

function NotFound() {
  return <section className="not-found"><div className="section-inner"><Eyebrow>404 / Not found</Eyebrow><h1>That page took a wrong turn.</h1><p>Let&apos;s get you back to the useful stuff.</p><Link href="/" className="button button-dark" data-testid="link-not-found-home">Back to home <ArrowRight aria-hidden="true" /></Link></div></section>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><ErrorBoundary resetKey="/"><Layout><Switch><Route path="/" component={HomePage} /><Route path="/approach" component={ApproachPage} /><Route path="/services" component={ServicesPage} /><Route path="/who-we-help" component={WhoWeHelpPage} /><Route path="/agricultural-accounting" component={AgriculturalPage} /><Route path="/outsource" component={OutsourcePage} /><Route path="/pricing" component={PricingPage} /><Route path="/faq" component={FaqPage} /><Route path="/contact" component={ContactPage} /><Route component={NotFound} /></Switch></Layout></ErrorBoundary><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;