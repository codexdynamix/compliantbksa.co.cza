CLARITY FINANCE ADVISORY — HOSTINGER UPLOAD

1. Build this package with:
   PORT=22127 BASE_PATH=/ pnpm --filter @workspace/clarity-finance-advisory run build

2. Upload the CONTENTS of the extracted dist/public folder to the domain's
   document root in Hostinger (usually public_html), including the hidden
   .htaccess file.

3. Open the domain. The site is a static React/Vite build and does not need
   Node.js, a database, or an API server on Hostinger.

4. The included .htaccess keeps direct visits and refreshes working for:
   /, /approach, /services, /who-we-help, /faq, and /contact.

Notes:
- The consultation form currently shows a client-side confirmation only.
- The WhatsApp bubble is visual-only until a real WhatsApp number is added.
- Replace the clearly marked contact placeholders in the source before
  publishing real business contact details.