import { useState, useEffect, useRef } from 'react';
import { motion, useScroll, useTransform, useInView } from 'framer-motion';
import { ArrowUpRight, ArrowDown, Plus, Minus, TrendingUp, ShieldCheck, Zap, Globe } from 'lucide-react';

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: (i = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.21, 0.47, 0.32, 0.98], delay: i * 0.08 },
  }),
};

function Counter({ end, suffix = '', prefix = '', decimals = 0 }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });
  const [val, setVal] = useState(0);

  useEffect(() => {
    if (!inView) return;
    let start = null;
    const dur = 1600;
    const step = (ts) => {
      if (!start) start = ts;
      const p = Math.min((ts - start) / dur, 1);
      const eased = 1 - Math.pow(1 - p, 4);
      setVal(eased * end);
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [inView, end]);

  return (
    <span ref={ref}>
      {prefix}
      {val.toFixed(decimals).replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
      {suffix}
    </span>
  );
}

function SectionLabel({ num, label }) {
  return (
    <div className="flex items-center gap-4 mb-10">
      <span className="font-mono text-[11px] tracking-[0.25em] text-[#FF4D00]">{num}</span>
      <div className="h-px flex-1 bg-[#1a1a1a]/15" />
      <span className="font-mono text-[11px] tracking-[0.25em] uppercase text-[#1a1a1a]/60">{label}</span>
    </div>
  );
}

export default function App() {
  const [openProcess, setOpenProcess] = useState(0);
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const heroImgY = useTransform(scrollYProgress, [0, 1], ['0%', '18%']);
  const heroTextY = useTransform(scrollYProgress, [0, 1], ['0%', '-30%']);

  const metrics = [
    { value: 312, suffix: '%', label: 'Increase in completed checkouts', sub: 'within 90 days of relaunch' },
    { value: 4.2, suffix: 'M', prefix: '$', decimals: 1, label: 'GMV in first quarter', sub: 'up from $980K previous quarter', },
    { value: 38, suffix: 's', label: 'Median time to list a pair', sub: 'down from 4 minutes 12 seconds' },
    { value: 71, suffix: '', label: 'NPS among power sellers', sub: 'previously 23' },
  ];

  const process = [
    {
      title: 'Field research with 42 resellers',
      body: 'We embedded with sneaker resellers in Atlanta, Tokyo, and London — from teenagers flipping pairs out of their bedroom to operations moving 400 pairs a month. The biggest finding: trust friction killed more sales than price ever did. Buyers abandoned carts not because of cost, but because authentication felt like a black box.',
    },
    {
      title: 'Authentication as the hero, not the fine print',
      body: 'Most marketplaces bury verification in a footnote. We made it the spine of the experience — a live "Verification Timeline" that shows every pair moving through intake, UV inspection, stitch analysis, and box-condition grading, with the authenticator\'s initials on every step. Disputes dropped 64%.',
    },
    {
      title: 'A listing flow built for speed culture',
      body: 'Power sellers list during drops, often from a sidewalk. We rebuilt listing around the camera: scan the size tag, and SoleStack auto-fills the SKU, colorway, retail price, and live market spread. Three taps from photo to live listing.',
    },
    {
      title: 'Pricing intelligence without the spreadsheet',
      body: 'The Heat Index aggregates last-sale velocity, ask/bid spread, and restock probability into a single signal. Sellers stopped exporting to Excel; 83% now price directly from the in-app recommendation.',
    },
  ];

  const gallery = [
    { src: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?w=900&h=1100&fit=crop', caption: 'Drop calendar — pre-release bid pools', tall: true },
    { src: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=900&h=700&fit=crop', caption: 'Verification timeline detail' },
    { src: 'https://images.unsplash.com/photo-1600269452121-4f2416e55c28?w=900&h=700&fit=crop', caption: 'Heat Index pricing module' },
    { src: 'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=900&h=1100&fit=crop', caption: 'Camera-first listing flow', tall: true },
  ];

  return (
    <div className="min-h-screen bg-[#F4F1EB] text-[#141414] antialiased selection:bg-[#FF4D00] selection:text-white">
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link
        href="https://fonts.googleapis.com/css2?family=Archivo:ital,wght@0,400;0,500;0,600;1,400&family=Archivo+Expanded:wght@500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap"
        rel="stylesheet"
      />
      <style
        dangerouslySetInnerHTML={{
          __html: `
        body { margin: 0; }
        .font-display { font-family: 'Archivo Expanded', 'Archivo', sans-serif; }
        .font-body { font-family: 'Archivo', sans-serif; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        .marquee-track { display: flex; width: max-content; animation: marquee 28s linear infinite; }
        @keyframes marquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }
        .img-hover { transition: transform 1s cubic-bezier(0.21, 0.47, 0.32, 0.98); }
        .img-wrap:hover .img-hover { transform: scale(1.04); }
        .grain::after {
          content: ''; position: fixed; inset: 0; pointer-events: none; z-index: 60; opacity: 0.35;
          background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.08'/%3E%3C/svg%3E");
        }
        ::-webkit-scrollbar { width: 10px; }
        ::-webkit-scrollbar-track { background: #F4F1EB; }
        ::-webkit-scrollbar-thumb { background: #141414; border-radius: 0; }
      `,
        }}
      />

      <div className="grain font-body">
        {/* NAV */}
        <nav className="fixed top-0 left-0 right-0 z-50 mix-blend-difference text-white">
          <div className="max-w-[1400px] mx-auto px-6 md:px-12 h-20 flex items-center justify-between">
            <span className="font-display font-800 text-lg tracking-tight" style={{ fontWeight: 800 }}>
              GRID&nbsp;&amp;&nbsp;NOISE<sup className="text-[10px] align-super ml-0.5">®</sup>
            </span>
            <div className="hidden md:flex items-center gap-10 font-mono text-[11px] tracking-[0.2em] uppercase">
              <a href="#" className="hover:opacity-60 transition-opacity">Work</a>
              <a href="#" className="hover:opacity-60 transition-opacity">Studio</a>
              <a href="#" className="hover:opacity-60 transition-opacity">Journal</a>
              <a href="#" className="flex items-center gap-1 hover:opacity-60 transition-opacity">
                Start a project <ArrowUpRight size={13} />
              </a>
            </div>
          </div>
        </nav>

        {/* HERO */}
        <header ref={heroRef} className="relative pt-36 md:pt-44 pb-0 overflow-hidden">
          <div className="max-w-[1400px] mx-auto px-6 md:px-12">
            <motion.div style={{ y: heroTextY }}>
              <motion.div initial="hidden" animate="visible" variants={fadeUp} className="flex flex-wrap items-center gap-3 mb-8">
                <span className="font-mono text-[11px] tracking-[0.25em] uppercase px-3 py-1.5 border border-[#141414]/30 rounded-full">Case Study — 014</span>
                <span className="font-mono text-[11px] tracking-[0.25em] uppercase px-3 py-1.5 bg-[#FF4D00] text-white rounded-full">2024</span>
              </motion.div>

              <motion.h1
                initial="hidden"
                animate="visible"
                custom={1}
                variants={fadeUp}
                className="font-display leading-[0.92] tracking-[-0.03em]"
                style={{ fontWeight: 800, fontSize: 'clamp(3rem, 9vw, 8.5rem)' }}
              >
                SOLESTACK
              </motion.h1>
              <motion.div initial="hidden" animate="visible" custom={2} variants={fadeUp} className="flex flex-col md:flex-row md:items-end justify-between gap-8 mt-6 mb-16">
                <p className="font-display text-xl md:text-3xl tracking-tight max-w-2xl leading-snug" style={{ fontWeight: 600 }}>
                  Rebuilding trust in the <span className="text-[#FF4D00]">$11B</span> sneaker resale market — from authentication to checkout.
                </p>
                <div className="grid grid-cols-2 gap-x-12 gap-y-4 font-mono text-[11px] tracking-[0.15em] uppercase shrink-0">
                  <div>
                    <p className="text-[#141414]/40 mb-1">Client</p>
                    <p>SoleStack Inc.</p>
                  </div>
                  <div>
                    <p className="text-[#141414]/40 mb-1">Timeline</p>
                    <p>16 Weeks</p>
                  </div>
                  <div>
                    <p className="text-[#141414]/40 mb-1">Scope</p>
                    <p>Product · Brand · iOS</p>
                  </div>
                  <div>
                    <p className="text-[#141414]/40 mb-1">Sector</p>
                    <p>Marketplace</p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.4, ease: [0.21, 0.47, 0.32, 0.98] }}
            className="max-w-[1400px] mx-auto px-6 md:px-12"
          >
            <div className="relative overflow-hidden rounded-t-[2rem] md:rounded-t-[3rem]">
              <motion.img
                style={{ y: heroImgY }}
                src="https://images.unsplash.com/photo-1556906781-9a412961c28c?w=2000&h=1100&fit=crop"
                alt="Sneaker hero"
                className="w-full h-[55vh] md:h-[75vh] object-cover scale-110"
              />
              <div className="absolute bottom-6 left-6 md:bottom-10 md:left-10 flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-[#F4F1EB] flex items-center justify-center">
                  <ArrowDown size={18} />
                </div>
                <span className="font-mono text-[11px] tracking-[0.2em] uppercase text-white mix-blend-difference">Scroll the study</span>
              </div>
              <div className="absolute bottom-6 right-6 md:bottom-10 md:right-10 font-mono text-[11px] tracking-[0.2em] uppercase text-white/90 bg-black/40 backdrop-blur-md px-4 py-2 rounded-full">
                Air Jordan 1 “Lost &amp; Found” — verified pair #048291
              </div>
            </div>
          </motion.div>
        </header>

        {/* MARQUEE */}
        <div className="bg-[#141414] text-[#F4F1EB] py-5 overflow-hidden border-y border-[#141414]">
          <div className="marquee-track font-display text-sm md:text-base tracking-[0.1em] uppercase" style={{ fontWeight: 600 }}>
            {[0, 1].map((k) => (
              <div key={k} className="flex items-center shrink-0">
                {['Verified Authentic', 'Live Heat Index', '38-Second Listings', '64% Fewer Disputes', 'Built for Drop Day'].map((t, i) => (
                  <span key={i} className="flex items-center">
                    <span className="px-8">{t}</span>
                    <span className="text-[#FF4D00]">✦</span>
                  </span>
                ))}
              </div>
            ))}
          </div>
        </div>

        {/* OVERVIEW */}
        <section className="max-w-[1400px] mx-auto px-6 md:px-12 py-24 md:py-36">
          <SectionLabel num="01" label="The Brief" />
          <div className="grid md:grid-cols-12 gap-10">
            <motion.h2
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-100px' }}
              variants={fadeUp}
              className="md:col-span-7 font-display text-3xl md:text-5xl leading-[1.05] tracking-[-0.02em]"
              style={{ fontWeight: 700 }}
            >
              SoleStack had inventory and hype. What it didn't have was a product people trusted with $400.
            </motion.h2>
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-100px' }}
              custom={2}
              variants={fadeUp}
              className="md:col-span-4 md:col-start-9 space-y-6 text-[15px] leading-relaxed text-[#141414]/75"
            >
              <p>
                Founded in 2021, SoleStack grew to 240,000 registered users on the strength of exclusive drop access. But cart abandonment sat at 78%, and the listing flow was so slow that top sellers defaulted to Instagram DMs and StockX.
              </p>
              <p>
                Grid &amp; Noise was brought in to redesign the entire commerce experience — buyer, seller, and authenticator — and reposition the brand for a generation that treats sneakers as both culture and asset class.
              </p>
              <div className="pt-4 flex flex-wrap gap-2">
                {['Product Strategy', 'UX Research', 'Design System', 'iOS App', 'Brand Identity', 'Motion'].map((t) => (
                  <span key={t} className="font-mono text-[10px] tracking-[0.15em] uppercase px-3 py-1.5 border border-[#141414]/20 rounded-full">
                    {t}
                  </span>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* METRICS */}
        <section className="bg-[#141414] text-[#F4F1EB] rounded-[2rem] md:rounded-[3rem] mx-3 md:mx-6">
          <div className="max-w-[1400px] mx-auto px-6 md:px-12 py-24 md:py-32">
            <div className="flex items-center gap-4 mb-16">
              <span className="font-mono text-[11px] tracking-[0.25em] text-[#FF4D00]">02</span>
              <div className="h-px flex-1 bg-white/15" />
              <span className="font-mono text-[11px] tracking-[0.25em] uppercase text-white/50">Outcomes</span>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-16">
              {metrics.map((m, i) => (
                <motion.div
                  key={i}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, margin: '-60px' }}
                  custom={i}
                  variants={fadeUp}
                  className="border-t border-white/15 pt-6"
                >
                  <p className="font-display tracking-[-0.03em] text-[#FF4D00]" style={{ fontWeight: 800, fontSize: 'clamp(2.5rem, 5vw, 4.5rem)' }}>
                    <Counter end={m.value} suffix={m.suffix} prefix={m.prefix || ''} decimals={m.decimals || 0} />
                  </p>
                  <p className="mt-3 text-sm leading-snug" style={{ fontWeight: 600 }}>{m.label}</p>
                  <p className="mt-1.5 font-mono text-[11px] text-white/45 tracking-wide">{m.sub}</p>
                </motion.div>
              ))}
            </div>

            <div className="mt-20 grid md:grid-cols-3 gap-px bg-white/10 rounded-2xl overflow-hidden">
              {[
                { icon: ShieldCheck, title: 'Verification Timeline', body: 'Every authentication step exposed to the buyer in real time — UV scan, stitch analysis, box grade — signed by a named authenticator.' },
                { icon: Zap, title: 'Camera-first Listing', body: 'Scan the size tag, get the SKU, colorway, market spread, and a price recommendation. Live in three taps.' },
                { icon: TrendingUp, title: 'Heat Index', body: 'A single 0–100 demand signal blending sale velocity, ask/bid spread, and restock probability — replacing seller spreadsheets.' },
              ].map((f, i) => (
                <div key={i} className="bg-[#141414] p-8 hover:bg-[#1d1d1d] transition-colors group">
                  <f.icon size={22} className="text-[#FF4D00] mb-5 group-hover:-translate-y-1 transition-transform" />
                  <h3 className="font-display text-base mb-2" style={{ fontWeight: 700 }}>{f.title}</h3>
                  <p className="text-sm text-white/55 leading-relaxed">{f.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* PROCESS */}
        <section className="max-w-[1400px] mx-auto px-6 md:px-12 py-24 md:py-36">
          <SectionLabel num="03" label="How we got there" />
          <div className="grid md:grid-cols-12 gap-12">
            <div className="md:col-span-5">
              <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="img-wrap overflow-hidden rounded-2xl sticky top-28">
                <img
                  src="https://images.unsplash.com/photo-1549298916-b41d501d3772?w=900&h=1200&fit=crop"
                  alt="Sneaker detail"
                  className="img-hover w-full h-[420px] md:h-[560px] object-cover"
                />
                <p className="font-mono text-[11px] tracking-[0.15em] uppercase text-[#141414]/50 mt-3">
                  Fig. 03 — Intake photography standard, Atlanta verification hub
                </p>
              </motion.div>
            </div>
            <div className="md:col-span-7">
              {process.map((p, i) => {
                const open = openProcess === i;
                return (
                  <div key={i} className="border-b border-[#141414]/15 first:border-t">
                    <button
                      onClick={() => setOpenProcess(open ? -1 : i)}
                      className="w-full flex items-start justify-between gap-6 py-7 text-left group"
                    >
                      <div className="flex items-baseline gap-5">
                        <span className="font-mono text-xs text-[#FF4D00]">0{i + 1}</span>
                        <span className="font-display text-lg md:text-2xl tracking-tight group-hover:text-[#FF4D00] transition-colors" style={{ fontWeight: 700 }}>
                          {p.title}
                        </span>
                      </div>
                      <span className="shrink-0 w-9 h-9 rounded-full border border-[#141414]/25 flex items-center justify-center group-hover:bg-[#141414] group-hover:text-[#F4F1EB] transition-colors">
                        {open ? <Minus size={15} /> : <Plus size={15} />}
                      </span>
                    </button>
                    <motion.div
                      initial={false}
                      animate={{ height: open ? 'auto' : 0, opacity: open ? 1 : 0 }}
                      transition={{ duration: 0.4, ease: [0.21, 0.47, 0.32, 0.98] }}
                      className="overflow-hidden"
                    >
                      <p className="pb-8 pl-0 md:pl-12 pr-4 text-[15px] leading-relaxed text-[#141414]/70 max-w-xl">{p.body}</p>
                    </motion.div>
                  </div>
                );
              })}

              <div className="mt-12 p-8 bg-[#E8E3D8] rounded-2xl">
                <Globe size={20} className="text-[#FF4D00] mb-4" />
                <p className="font-display text-lg leading-snug tracking-tight" style={{ fontWeight: 600 }}>
                  Three verification hubs. Eleven currencies. One design system spanning buyer app, seller dashboard, and authenticator hardware terminals.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* GALLERY */}
        <section className="max-w-[1400px] mx-auto px-6 md:px-12 pb-24 md:pb-36">
          <SectionLabel num="04" label="The work, up close" />
          <div className="grid md:grid-cols-2 gap-6 md:gap-8">
            {gallery.map((g, i) => (
              <motion.figure
                key={i}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: '-60px' }}
                custom={i % 2}
                variants={fadeUp}
                className={`img-wrap ${i % 2 === 1 ? 'md:mt-20' : ''}`}
              >
                <div className="overflow-hidden rounded-2xl">
                  <img src={g.src} alt={g.caption} className={`img-hover w-full object-cover ${g.tall ? 'h-[420px] md:h-[640px]' : 'h-[320px] md:h-[440px]'}`} />
                </div>
                <figcaption className="flex items-center justify-between mt-3 font-mono text-[11px] tracking-[0.15em] uppercase text-[#141414]/50">
                  <span>{g.caption}</span>
                  <span>0{i + 1} / 04</span>
                </figcaption>
              </motion.figure>
            ))}
          </div>
        </section>

        {/* QUOTE */}
        <section className="bg-[#FF4D00] text-[#141414] rounded-[2rem] md:rounded-[3rem] mx-3 md:mx-6 overflow-hidden">
          <div className="max-w-[1100px] mx-auto px-6 md:px-12 py-24 md:py-36 text-center">
            <motion.p
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-80px' }}
              variants={fadeUp}
              className="font-display leading-[1.05] tracking-[-0.02em]"
              style={{ fontWeight: 700, fontSize: 'clamp(1.6rem, 4vw, 3.4rem)' }}
            >
              “Grid &amp; Noise didn't just redesign our app — they understood that resale is a trust business wearing a sneaker costume. GMV quadrupled because buyers finally believed us.”
            </motion.p>
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} custom={2} variants={fadeUp} className="mt-10 flex items-center justify-center gap-4">
              <img
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&h=120&fit=crop"
                alt="Marcus Bell"
                className="w-12 h-12 rounded-full object-cover border-2 border-[#141414]"
              />
              <div className="text-left">
                <p className="font-display text-sm" style={{ fontWeight: 700 }}>Marcus Bell</p>
                <p className="font-mono text-[11px] tracking-[0.15em] uppercase opacity-70">Co-founder &amp; CEO, SoleStack</p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* NEXT / FOOTER */}
        <footer className="max-w-[1400px] mx-auto px-6 md:px-12 pt-24 md:pt-36 pb-12">
          <p className="font-mono text-[11px] tracking-[0.25em] uppercase text-[#141414]/50 mb-4">Next case study</p>
          <a href="#" className="group block border-b border-[#141414]/20 pb-10">
            <div className="flex items-end justify-between gap-6">
              <h3 className="font-display tracking-[-0.03em] leading-[0.95] group-hover:text-[#FF4D00] transition-colors" style={{ fontWeight: 800, fontSize: 'clamp(2.2rem, 7vw, 6rem)' }}>
                NIGHTSHIFT<br />RECORDS
              </h3>
              <span className="shrink-0 w-16 h-16 md:w-24 md:h-24 rounded-full border border-[#141414]/25 flex items-center justify-center group-hover:bg-[#141414] group-hover:text-[#F4F1EB] group-hover:rotate-45 transition-all duration-500">
                <ArrowUpRight size={28} />
              </span>
            </div>
            <p className="mt-4 font-mono text-[11px] tracking-[0.2em] uppercase text-[#141414]/50">Vinyl subscription platform — Brand · Web · Packaging</p>
          </a>
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mt-12 font-mono text-[11px] tracking-[0.2em] uppercase text-[#141414]/50">
            <span>© 2024 Grid &amp; Noise Studio</span>
            <div className="flex gap-8">
              <a href="#" className="hover:text-[#FF4D00] transition-colors">Instagram</a>
              <a href="#" className="hover:text-[#FF4D00] transition-colors">Are.na</a>
              <a href="#" className="hover:text-[#FF4D00] transition-colors">hello@gridandnoise.studio</a>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}